# NM Dev benchmark output

Suite: FULL. All measurements are local to the machine recorded in machine.json.

Case checkpoints include two independently warmed JVM forks. Fork JSON is preserved verbatim; combined JSON uses JMH's own aggregators. Requested native thread counts are not independently audited.

Upload the sibling *-results.zip. It excludes licenses, downloaded binaries, credentials and private runtime cache. Partial runs are explicitly marked in progress.json. To resume, keep the complete local output directory, including .runtime and binary fork checkpoints, and run the same JAR again.
